from django.shortcuts import render


def inicio(request):

    resultado = None

    if request.method == 'POST':

        numeros = request.POST.get('numeros')

        lista = list(map(int, numeros.split(',')))

        suma = sum(lista)

        promedio = suma / len(lista)

        mayor = max(lista)

        menor = min(lista)

        pares = list(filter(lambda x: x % 2 == 0, lista))

        impares = list(filter(lambda x: x % 2 != 0, lista))

        cuadrados = list(map(lambda x: x**2, lista))

        mayores_promedio = list(
            filter(lambda x: x > promedio, lista)
        )

        resultado = {
            'lista': lista,
            'suma': suma,
            'promedio': promedio,
            'mayor': mayor,
            'menor': menor,
            'pares': pares,
            'impares': impares,
            'cuadrados': cuadrados,
            'mayores_promedio': mayores_promedio
        }

    return render(
        request,
        'analizador/inicio.html',
        {'resultado': resultado}
    )